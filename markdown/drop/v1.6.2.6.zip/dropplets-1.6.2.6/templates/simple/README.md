## Simple v1.0.2 by Jason Schuller (Jason.sc)
Copyright Circa75 Media, LLC (Circa75.co)

### License
[Creative Commons - CC BY-NC](http://creativecommons.org/licenses/by-nc/3.0/legalcode)

### Need Help?
Help is just an email away... help@dropplets.com.

#### Version 1.0.2
- REVISED: Single post pages now include the Post Content tag integrated in Dropplets version 1.5.4.

#### Version 1.0.1
- FIXED: Missing post thumbnail on 404 page.

#### Version 1.0.0
- NEW: Initial release.