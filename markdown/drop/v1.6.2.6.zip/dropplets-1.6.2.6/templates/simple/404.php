<article class="single not-found">
    <div class="row">
        <div class="one-quarter meta">
            <div class="thumbnail">
            </div>
        </div>

        <div class="three-quarters post">
            <h1><?php echo($error_title); ?></h1>
            <p><?php echo($error_text); ?></p>

            <ul class="actions">
                <li><a class="button" href="<?php echo($blog_url); ?>">More Articles</a></li>
            </ul>
        </div>
    </div>
</article>