#!/bin/zsh
#[^[:alnum:][:blank:][:digit:][:graph:][:lower:][:print:][:punct:][:space:][:xdigit:]].....
sed 's/\& /\&amp;/g' |
sed 's/├ö├ç┬ú/\&ldquo;/g' |
sed 's/├ö├ç├ÿ/\&rdquo;/g' |
sed 's/├ö├ç├û/\&rsquo;/g' |